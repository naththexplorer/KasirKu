// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'shop_setup_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$isShopSetupHash() => r'54885c300a5b830b18f584d15061343b37484007';

/// See also [isShopSetup].
@ProviderFor(isShopSetup)
final isShopSetupProvider = AutoDisposeFutureProvider<bool>.internal(
  isShopSetup,
  name: r'isShopSetupProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$isShopSetupHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef IsShopSetupRef = AutoDisposeFutureProviderRef<bool>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
